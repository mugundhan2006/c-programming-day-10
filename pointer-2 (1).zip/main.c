#include <stdio.h>

int main() {
    int a = 10, b = 20;
    int *it, *csa;

    it = &a;
    csa = &b;

    ++a;        
    --b;        
    ++*it;      
    --*csa;     

    printf("%d, %d", a, b);

    printf("\n%p %p", (void *)&a, (void *)&b);
    printf("\n%p %p", (void *)it, (void *)csa);
    printf("\n%p %p", (void *)&it, (void *)&csa);

    return 0;
}
